#!/bin/bash
source env.sh
rm -rf ${hd_dir}/data/*db*
