cat ./logs/*.log|grep "100%"
