#!/bin/bash
HMINER_INDEPENDENT=${PWD}/../../
INSTALLDIR=${PWD}/_install

export HMINER_INDEPENDENT=$HMINER_INDEPENDENT

# mkdir -p ${INSTALLDIR}
export CC=arm-linux-gnueabihf-gcc
export CXX=arm-linux-gnueabihf-g++
export AR=arm-linux-gnueabihf-ar
export RANLIB=arm-linux-gnueabihf-ranlib

./configure --host=arm-linux-gnueabihf --prefix=${INSTALLDIR}
make HOSTPYTHON=./hostpython HOSTPGEN=./Parser/hostpgen BLDSHARED="arm-linux-gnueabihf-gcc -shared" HOSTARCH=arm-linux-gnueabihf CROSS_COMPILE=arm-linux-gnueabihf- CROSS_COMPILE_TARGET=yes

make install HOSTPYTHON=./hostpython BLDSHARED="arm-linux-gnueabihf-gcc -shared" CROSS_COMPILE=arm-linux-gnueabihf- CROSS_COMPILE_TARGET=yes prefix=${INSTALLDIR}

